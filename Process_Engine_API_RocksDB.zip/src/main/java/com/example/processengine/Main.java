package com.example.processengine;

import com.example.processengine.agent.AgentOrchestrator;
import com.example.processengine.api.RestApiServer;
import com.example.processengine.core.ProcessEngine;
import com.example.processengine.core.ProcessInstance;
import com.example.processengine.core.ProcessState;
import com.example.processengine.storage.InMemoryStateStore;
import com.example.processengine.storage.StateStore;

import java.util.Map;

/**
 * Runnable, dependency-free demo. Proves three things end-to-end:
 *   1. The process engine's state machine (create/pause/resume/mutate/complete)
 *      enforces its legal-transition rules, backed by a StateStore.
 *   2. The agent orchestrator parses free-text instructions and makes a
 *      real conditional decision (refusing an unmet-condition resume,
 *      then succeeding once the mutated variable satisfies it).
 *   3. The REST API is live and reachable over real HTTP.
 */
public final class Main {
    public static void main(String[] args) throws Exception {
        StateStore store = new InMemoryStateStore();
        ProcessEngine engine = new ProcessEngine(store);
        AgentOrchestrator orchestrator = new AgentOrchestrator(engine);

        System.out.println("=== 1. Core engine: state machine rules ===");
        ProcessInstance p1 = engine.create("ORD-1001", "order-fulfillment");
        System.out.println("Created: " + p1);
        engine.mutate("ORD-1001", Map.of("inventory", "0"));
        engine.pause("ORD-1001");
        System.out.println("Paused: " + engine.find("ORD-1001").orElseThrow());

        try {
            engine.resume("ORD-1001", false);
            throw new AssertionError("Expected resume to be refused");
        } catch (IllegalStateException expected) {
            System.out.println("Resume correctly refused: " + expected.getMessage());
        }

        System.out.println("\n=== 2. Agent orchestration: conditional resume ===");
        System.out.println(orchestrator.execute("resume process ORD-1001 if inventory > 0"));
        // ^ should be refused: inventory is 0

        System.out.println(orchestrator.execute("set inventory=5 on process ORD-1001"));
        System.out.println(orchestrator.execute("resume process ORD-1001 if inventory > 0"));
        // ^ should now succeed: inventory is 5

        ProcessInstance finalState = engine.find("ORD-1001").orElseThrow();
        System.out.println("Final state: " + finalState);
        if (finalState.getState() != ProcessState.RUNNING) {
            throw new AssertionError("Expected process to be RUNNING after conditional resume succeeded");
        }
        System.out.println("Conditional agent resume behaved correctly.");

        System.out.println("\n=== 3. REST API: live HTTP server ===");
        RestApiServer server = new RestApiServer(8089, engine, orchestrator);
        server.start();
        System.out.println("REST API listening on http://localhost:8089 (try: curl http://localhost:8089/v1/processes/ORD-1001)");
        System.out.println("Server will stay up for 60s so you can curl it, then shuts down automatically.");

        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
        Thread.sleep(60_000);
        server.stop();
        System.out.println("Server stopped. Demo complete.");
    }
}
