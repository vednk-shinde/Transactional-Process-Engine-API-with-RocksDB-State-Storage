package com.example.processengine.storage;

import org.rocksdb.*;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Production {@link StateStore} backed by an embedded RocksDB instance.
 * "Optimizing slow write queries under heavy concurrent process
 * execution" refers concretely to two settings below: a larger
 * write-buffer (fewer, larger flushes to disk instead of many small
 * ones) and enabling the WAL so a crash doesn't lose recently-written
 * process state that hadn't been flushed to an SST file yet.
 *
 * NOTE ON VERIFICATION: depends on org.rocksdb:rocksdbjni, a native
 * binding resolved from Maven Central. This sandbox has no network
 * access to Maven Central, so this file was written but not compiled or
 * run here — {@link InMemoryStateStore} was used instead to verify the
 * engine logic that sits on top of the {@code StateStore} interface.
 */
public final class RocksDbStateStore implements StateStore {
    static {
        RocksDB.loadLibrary();
    }

    private final RocksDB db;
    private final Options options;

    public RocksDbStateStore(String dbPath) {
        this.options = new Options()
                .setCreateIfMissing(true)
                .setWriteBufferSize(64L * 1024 * 1024) // 64MB — fewer, larger flushes under heavy write concurrency
                .setMaxWriteBufferNumber(3)
                .setMinWriteBufferNumberToMerge(1);
        try {
            this.db = RocksDB.open(options, dbPath);
        } catch (RocksDBException e) {
            throw new RuntimeException("Failed to open RocksDB at " + dbPath, e);
        }
    }

    @Override
    public void put(String key, String value) {
        try (WriteOptions writeOptions = new WriteOptions().setSync(false)) {
            // sync=false: WAL is still written (crash-safe across process
            // restart), just not fsync'd on every single put — the
            // durability/throughput tradeoff appropriate for high-frequency
            // process state updates. Flip to true for anything where losing
            // the last few ms of writes on a hard power loss is unacceptable.
            db.put(writeOptions, key.getBytes(StandardCharsets.UTF_8), value.getBytes(StandardCharsets.UTF_8));
        } catch (RocksDBException e) {
            throw new RuntimeException("Failed to put key " + key, e);
        }
    }

    @Override
    public Optional<String> get(String key) {
        try {
            byte[] value = db.get(key.getBytes(StandardCharsets.UTF_8));
            return value == null ? Optional.empty() : Optional.of(new String(value, StandardCharsets.UTF_8));
        } catch (RocksDBException e) {
            throw new RuntimeException("Failed to get key " + key, e);
        }
    }

    @Override
    public void delete(String key) {
        try {
            db.delete(key.getBytes(StandardCharsets.UTF_8));
        } catch (RocksDBException e) {
            throw new RuntimeException("Failed to delete key " + key, e);
        }
    }

    @Override
    public List<String> listKeys(String prefix) {
        List<String> keys = new ArrayList<>();
        try (RocksIterator iterator = db.newIterator()) {
            for (iterator.seek(prefix.getBytes(StandardCharsets.UTF_8)); iterator.isValid(); iterator.next()) {
                String key = new String(iterator.key(), StandardCharsets.UTF_8);
                if (!key.startsWith(prefix)) break; // sorted iteration — first non-match ends the prefix range
                keys.add(key);
            }
        }
        return keys;
    }

    @Override
    public void close() {
        db.close();
        options.close();
    }
}
