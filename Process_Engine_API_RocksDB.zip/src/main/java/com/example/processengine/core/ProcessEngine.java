package com.example.processengine.core;

import com.example.processengine.storage.StateStore;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The engine's job is narrow and specific: hold the legal state-transition
 * rules, keep an in-memory index of live {@link ProcessInstance}s for
 * fast reads, and durably persist every change through {@link StateStore}
 * before returning success to the caller — "fast local state validation"
 * means the in-memory check happens first and is authoritative for
 * whether a transition is *legal*; the store write is what makes it durable.
 */
public final class ProcessEngine {
    private static final String KEY_PREFIX = "process:";

    private final StateStore store;
    private final Map<String, ProcessInstance> liveInstances = new ConcurrentHashMap<>();

    public ProcessEngine(StateStore store) {
        this.store = store;
    }

    public ProcessInstance create(String processId, String processType) {
        if (liveInstances.containsKey(processId) || store.get(KEY_PREFIX + processId).isPresent()) {
            throw new IllegalStateException("Process " + processId + " already exists");
        }
        ProcessInstance instance = new ProcessInstance(processId, processType);
        instance.setState(ProcessState.RUNNING);
        persist(instance);
        return instance;
    }

    public ProcessInstance pause(String processId) {
        ProcessInstance instance = require(processId);
        if (instance.getState() != ProcessState.RUNNING) {
            throw new IllegalStateException("Cannot pause process in state " + instance.getState());
        }
        instance.setState(ProcessState.PAUSED);
        persist(instance);
        return instance;
    }

    /**
     * Resumes a paused process — but only if {@code condition} evaluates
     * true against the process's current variables. This is the hook the
     * agent orchestrator calls for a conditional resume like "resume when
     * inventory > 0": the condition logic lives in
     * {@code agent.ConditionEvaluator}, this method just enforces that a
     * false condition means the resume is refused, not silently ignored.
     */
    public ProcessInstance resume(String processId, boolean conditionMet) {
        ProcessInstance instance = require(processId);
        if (instance.getState() != ProcessState.PAUSED) {
            throw new IllegalStateException("Cannot resume process in state " + instance.getState());
        }
        if (!conditionMet) {
            throw new IllegalStateException("Resume condition not met for process " + processId);
        }
        instance.setState(ProcessState.RUNNING);
        persist(instance);
        return instance;
    }

    public ProcessInstance mutate(String processId, Map<String, String> variableUpdates) {
        ProcessInstance instance = require(processId);
        if (instance.getState() == ProcessState.COMPLETED || instance.getState() == ProcessState.FAILED) {
            throw new IllegalStateException("Cannot mutate a terminal process (state=" + instance.getState() + ")");
        }
        variableUpdates.forEach(instance::setVariable);
        persist(instance);
        return instance;
    }

    public ProcessInstance complete(String processId) {
        ProcessInstance instance = require(processId);
        instance.setState(ProcessState.COMPLETED);
        persist(instance);
        return instance;
    }

    public Optional<ProcessInstance> find(String processId) {
        ProcessInstance live = liveInstances.get(processId);
        if (live != null) return Optional.of(live);
        return store.get(KEY_PREFIX + processId).map(v -> ProcessInstance.deserialize(processId, v));
    }

    private ProcessInstance require(String processId) {
        return find(processId).orElseThrow(() -> new IllegalArgumentException("No such process: " + processId));
    }

    private void persist(ProcessInstance instance) {
        liveInstances.put(instance.getProcessId(), instance);
        store.put(KEY_PREFIX + instance.getProcessId(), instance.serializeValue());
    }
}
