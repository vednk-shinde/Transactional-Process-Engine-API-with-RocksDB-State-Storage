package com.example.processengine.core;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A single running process instance and its state variables. Variables
 * are what the agent (see {@code agent.AgentOrchestrator}) reads to
 * decide whether a conditional resume is legal — e.g. "resume when
 * inventory > 0" is evaluated against {@link #variables}, not hardcoded.
 *
 * Mutable by design (a process instance changes over its lifetime) but
 * every mutation goes through {@link ProcessEngine}, which is the only
 * class that also writes the change to the {@code StateStore} — nothing
 * in this class touches storage directly.
 */
public final class ProcessInstance {
    private final String processId;
    private final String processType;
    private volatile ProcessState state;
    private final Map<String, String> variables = new LinkedHashMap<>();
    private final Instant createdAt;
    private volatile Instant updatedAt;
    private volatile String lastError;

    public ProcessInstance(String processId, String processType) {
        this.processId = processId;
        this.processType = processType;
        this.state = ProcessState.CREATED;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    public String getProcessId() { return processId; }
    public String getProcessType() { return processType; }
    public ProcessState getState() { return state; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getLastError() { return lastError; }

    public synchronized void setState(ProcessState newState) {
        this.state = newState;
        this.updatedAt = Instant.now();
    }

    public synchronized void setVariable(String key, String value) {
        variables.put(key, value);
        this.updatedAt = Instant.now();
    }

    public String getVariable(String key) {
        return variables.get(key);
    }

    public synchronized Map<String, String> variablesSnapshot() {
        return Map.copyOf(variables);
    }

    public synchronized void fail(String reason) {
        this.state = ProcessState.FAILED;
        this.lastError = reason;
        this.updatedAt = Instant.now();
    }

    /** Serializes to a single line for the embedded key-value store: processId|type|state|updatedAt|k1=v1,k2=v2 */
    public String serializeValue() {
        StringBuilder vars = new StringBuilder();
        variables.forEach((k, v) -> {
            if (vars.length() > 0) vars.append(",");
            vars.append(k).append("=").append(v);
        });
        return processType + "|" + state + "|" + updatedAt + "|" + vars;
    }

    public static ProcessInstance deserialize(String processId, String value) {
        String[] parts = value.split("\\|", 4);
        if (parts.length < 4) throw new IllegalArgumentException("corrupt process record for " + processId);
        ProcessInstance instance = new ProcessInstance(processId, parts[0]);
        instance.state = ProcessState.valueOf(parts[1]);
        if (!parts[3].isBlank()) {
            for (String kv : parts[3].split(",")) {
                String[] p = kv.split("=", 2);
                if (p.length == 2) instance.variables.put(p[0], p[1]);
            }
        }
        return instance;
    }

    @Override
    public String toString() {
        return "Process{" + processId + ", type=" + processType + ", state=" + state
                + ", vars=" + variables + (lastError != null ? ", error=" + lastError : "") + "}";
    }
}
