# Transactional Process Engine API with RocksDB State Storage

A process orchestration engine — create/pause/resume/mutate/complete a long-running transactional process — with a versioned REST/gRPC API contract, an embedded RocksDB-backed metadata store, and an agent that parses free-text instructions into real, conditional state changes.

## What's actually verified vs. what isn't

| Layer | Package | Dependencies | Verified how |
|---|---|---|---|
| **Core engine + agent + REST API** | `core`, `agent`, `api`, `storage.InMemoryStateStore` | none (JDK only) | Compiled with `javac` and **run** — hit with real `curl` requests, see results below |
| **RocksDB adapter** | `storage.RocksDbStateStore` | `org.rocksdb:rocksdbjni` (Maven Central) | Written, not compiled — no Maven Central access in this sandbox |
| **gRPC contract** | `proto/process_engine_v1.proto` | none to validate | **Compiled with the real `protoc` compiler** — a genuine syntax/schema check, not just hand review |
| **gRPC generated stubs** | (not present) | `io.grpc:*`, Maven Central | Not generated here — `mvn generate-sources` will produce them once you have registry access |

## What I actually ran, and what happened

**Core engine + agent orchestration (no server needed):**
```
=== 1. Core engine: state machine rules ===
Created: Process{ORD-1001, type=order-fulfillment, state=RUNNING, vars={}}
Paused: Process{ORD-1001, type=order-fulfillment, state=PAUSED, vars={inventory=0}}
Resume correctly refused: Resume condition not met for process ORD-1001

=== 2. Agent orchestration: conditional resume ===
Resume refused for ORD-1001: condition 'inventory > 0' not met (current value: 0).
Updated ORD-1001 variables: {inventory=5}
Resumed ORD-1001 (condition 'inventory > 0' met).
Final state: Process{ORD-1001, type=order-fulfillment, state=RUNNING, vars={inventory=5}}
Conditional agent resume behaved correctly.
```

**Live REST API, hit with real `curl`:**
```
--- GET existing process ---
{"processId":"ORD-1001","processType":"order-fulfillment","state":"RUNNING","variables":{"inventory":"5"}}
--- POST create new process ---
{"processId":"ORD-2002","processType":"refund","state":"RUNNING","variables":{}}
--- POST pause it ---
{"processId":"ORD-2002","processType":"refund","state":"PAUSED","variables":{}}
--- agent instruction: mutate ---
{"result":"Updated ORD-2002 variables: {refundAmount=50}"}
--- agent instruction: resume with unmet condition (should be refused) ---
{"result":"Resume refused for ORD-2002: condition 'refundAmount > 100' not met (current value: 50)."}
--- 404 for unknown process ---
404
```

## Architecture

```
"pause process ORD-1001"  ──▶  IntentParser  ──▶  AgentCommand (typed)
"resume process X if inventory > 0"                   │
"set sku=ABC on process X"                             ▼
                                              AgentOrchestrator ──▶ ConditionEvaluator
                                                        │           (evaluates against
                                                        ▼            live process variables)
REST API (/v1/processes, /v1/agent/instruction) ──▶ ProcessEngine
gRPC API (process_engine_v1.proto, same operations)      │
                                                          ▼
                                                    StateStore
                                          (InMemoryStateStore locally /
                                           RocksDbStateStore in production)
```

## The three resume claims, and exactly where they live in the code

1. **"gRPC and RESTful API contract layer featuring comprehensive backward compatibility frameworks"** — `proto/process_engine_v1.proto` (protoc-validated) documents and follows four concrete rules in its header comment: field numbers are never reused (`reserved 5; reserved "legacy_status_code";` shows this in practice), new fields are always optional additions, breaking changes ship as a new package (`v2`) rather than mutating `v1`, and enums reserve index 0 as `_UNSPECIFIED`. The REST layer (`api/RestApiServer.java`) mirrors the same policy under `/v1/`.
2. **"RocksDB as an embedded key-value metadata store... optimizing slow write queries under heavy concurrent process execution"** — `storage/RocksDbStateStore.java`: a 64MB write buffer with `setMinWriteBufferNumberToMerge(1)` (fewer, larger flushes instead of many small ones under write pressure) and `WriteOptions().setSync(false)` (WAL-durable but not fsync'd per write) — a concrete, explainable durability/throughput tradeoff, not a default left untouched.
3. **"Intelligent agent processing tool that parses intent and dynamically pauses, mutates, or resumes... based on system state variables"** — `agent/IntentParser.java` + `agent/ConditionEvaluator.java` + `agent/AgentOrchestrator.java`. Demonstrated live above: the agent refuses a resume when the condition is false against real process state, and succeeds once a prior agent-issued mutate changes that state.

## Running it

```bash
# Core + agent + REST API only (no Maven Central needed) — exactly what produced the output above:
javac -d out $(find src/main/java/com/example/processengine/core \
  src/main/java/com/example/processengine/agent \
  src/main/java/com/example/processengine/api \
  src/main/java/com/example/processengine/storage/StateStore.java \
  src/main/java/com/example/processengine/storage/InMemoryStateStore.java \
  src/main/java/com/example/processengine/Main.java -name "*.java")
java -cp out com.example.processengine.Main
# then, in another terminal:
curl http://localhost:8089/v1/processes/ORD-1001
curl -X POST http://localhost:8089/v1/agent/instruction \
  -H "Content-Type: application/json" \
  -d '{"instruction":"resume process ORD-1001 if inventory > 0"}'

# Full build including RocksDB + generated gRPC stubs, once you have Maven Central access:
mvn compile
```

## Honest scope notes (say this in an interview if asked)

- `RocksDbStateStore` was written against the real `rocksdbjni` API (correct `Options`/`WriteOptions` usage as far as I can verify from documentation) but **not compiled or run** — this sandbox had no network path to Maven Central. Run `mvn compile` yourself and be ready to show it building before claiming this part works.
- No gRPC service implementation exists yet (`ProcessEngineServiceImpl` implementing the generated stub) — only the `.proto` contract, which **was** verified with `protoc`. Generating the stubs (`mvn generate-sources`) and writing the service implementation is the natural next step, not something skipped by accident.
- The REST API's JSON parsing is a deliberately minimal regex-based parser for flat `{"key":"value"}` bodies — good enough for this demo's request shapes, not a general JSON library. Swap in Jackson for anything beyond flat string-valued objects.
- `ConditionEvaluator` supports a small, explicit grammar (`variable <op> value`), not a general expression language — scoped intentionally to prove the orchestration logic, not to be a rules engine.

## Suggested next steps to make it fully yours

1. Run `mvn compile`, fix whatever the real RocksDB/gRPC APIs flag that this write-up got wrong, and note the diff — that's how "written" becomes "verified."
2. Implement `ProcessEngineServiceImpl` against the generated gRPC stubs, backed by the same `ProcessEngine` class the REST API already uses — proving the API-layer/business-logic separation actually holds.
3. Swap `InMemoryStateStore` for `RocksDbStateStore` in `Main` and rerun the exact same demo scenarios against real embedded storage, including a restart-and-recover test.
